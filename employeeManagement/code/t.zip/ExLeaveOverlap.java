
@SuppressWarnings("serial")
public class ExLeaveOverlap extends Exception{
	public ExLeaveOverlap() {super("Overlap with leave before!");}
	public ExLeaveOverlap(String message) {super(message);}
}
