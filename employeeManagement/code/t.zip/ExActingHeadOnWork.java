
@SuppressWarnings("serial")
public class ExActingHeadOnWork extends Exception{
	public ExActingHeadOnWork() {super("Team not found!");}
	public ExActingHeadOnWork(String message) {super(message);}
}
