
@SuppressWarnings("serial")
public class ExActingHeadMissing extends Exception{
	public ExActingHeadMissing() {super("Overlap with leave before!");}
	public ExActingHeadMissing(String message) {super(message);}
}
